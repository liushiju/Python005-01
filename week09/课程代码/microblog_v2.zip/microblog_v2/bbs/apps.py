from django.apps import AppConfig


class BbsConfig(AppConfig):
    name = 'bbs'
